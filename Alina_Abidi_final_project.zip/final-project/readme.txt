Alina Abidi
J320 Spring 2017

Summary: I wanted to take a look at student employees across campus who are part of the work study program, and share their perspectives in an interactive way.

1. Question: Click on the colored box to change the question presented. The audio that results from clicking each person changes depending on which question is being asked. I changed the question and the box color by creating an array for each and using a counter and the mod operator to index through each array and keep them in synch. 

2. Hover: To make the images more dynamic, when you hover over each person, the image shifts from a candid shot to a smiling one.

3. Audio: When each person is clicked on, I use the counter to see what question is currently displaying, and play the audio response that matches the question. 

4. Toggle: I transcribed each interview and presented it at the bottom as a toggle. 